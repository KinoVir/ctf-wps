# FLAG and key is different on the real server
FLAG = b'justCTF{flag will be there}'
key = 0x101010101010101010
